#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>

int main()
{
    sf::RenderWindow window(sf::VideoMode(775, 868), "Beata ma chuja :D");
    sf::Texture texture[2];
        texture[0].loadFromFile("beata.jpeg");
        texture[1].loadFromFile("xd.jpg");
    sf::Sprite sprite[2];
        sprite[0].setTexture(texture[0]);
        sprite[1].setTexture(texture[1]);
        sprite[1].setScale(1.076388889, 1.238231098);
    sf::Music music[2];
        music[0].openFromFile("music.ogg");
        music[1].openFromFile("POU.ogg");
        music[1].play();
     sf::Event event;
    bool t = true;

    while(window.isOpen())
    {   
        while(window.pollEvent(event))
        {
            switch(event.type)
            {
                case sf::Event::Closed:
                    window.close();
                    break;
                case sf::Event::KeyPressed:
                    if(event.key.code == sf::Keyboard::Escape)
                        window.close();
                    break;
                case sf::Event::MouseButtonPressed:
                {
                    if(event.mouseButton.button == sf::Mouse::Left)
                    {
                        if(t == false)
                        {
                            music[0].stop();
                            t = true; 
                            music[1].play();
                        }
                        else 
                        {
                            music[1].stop();
                            t = false;
                            music[0].play();
                        }
                    }         
                }
                break; 
            }
        }

        
        window.clear();
        if(t) window.draw(sprite[0]);
        else window.draw(sprite[1]);
        window.display();
    }
    

    return 0;
} 